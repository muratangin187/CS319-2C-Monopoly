class City{
    constructor(name, rent, price, mortgage, houseCost, hotelCost, color) {
        this.name = name;
        this.rent = rent;
        this.price = price;
        this.mortgage = mortgage;
        this.houseCost = houseCost;
        this.hotelCost = hotelCost;
        this.color = color;
    }
}