class Chance {
    constructor(description) {
        this.description = description;
    }
}